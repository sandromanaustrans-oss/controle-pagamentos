package br.com.controlepagamentos

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY category, dueDay, description")
    fun observeAll(): Flow<List<Payment>>

    @Insert
    suspend fun insertAll(items: List<Payment>)

    @Insert
    suspend fun insert(item: Payment)

    @Update
    suspend fun update(item: Payment)

    @Query("SELECT COUNT(*) FROM payments")
    suspend fun count(): Int
}

@Database(entities = [Payment::class], version = 1, exportSchema = false)
abstract class PaymentDatabase : RoomDatabase() {
    abstract fun paymentDao(): PaymentDao
    companion object {
        @Volatile private var INSTANCE: PaymentDatabase? = null
        fun get(context: Context): PaymentDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PaymentDatabase::class.java,
                    "controle_pagamentos.db"
                ).build().also { INSTANCE = it }
            }
    }
}
