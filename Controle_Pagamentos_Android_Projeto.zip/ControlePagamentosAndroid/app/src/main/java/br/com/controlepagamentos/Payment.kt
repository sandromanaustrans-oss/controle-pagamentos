package br.com.controlepagamentos

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val description: String,
    val amountCents: Long = 0,
    val dueDay: Int = 10,
    val isPaid: Boolean = false,
    val notes: String = ""
)

data class SeedPayment(val category: String, val description: String)

val initialPayments = listOf(
    SeedPayment("Seguros", "Residencial"),
    SeedPayment("Seguros", "Vida"),
    SeedPayment("Seguros", "Kicks"),
    SeedPayment("Seguros", "Corolla"),
    SeedPayment("Cartões", "BMG"),
    SeedPayment("Cartões", "Nubank"),
    SeedPayment("Cartões", "Carrefour"),
    SeedPayment("Cartões", "Tricard"),
    SeedPayment("Cartões", "DB"),
    SeedPayment("Moradia", "IPTU Weekend"),
    SeedPayment("Moradia", "IPTU Iranduba"),
    SeedPayment("Moradia", "Cond Weekend"),
    SeedPayment("Moradia", "Terreno Açutuba"),
    SeedPayment("Moradia", "Ambar Weekend"),
    SeedPayment("Moradia", "Ambar Conquista"),
    SeedPayment("Moradia", "Warylex"),
    SeedPayment("Moradia", "Net Claro"),
    SeedPayment("Moradia", "CEF Apto"),
    SeedPayment("Moradia", "Aluguel Conquista"),
    SeedPayment("Transporte", "Positron"),
    SeedPayment("Transporte", "Corolla Parcela"),
    SeedPayment("Transporte", "Kicks Parcela"),
    SeedPayment("Empréstimos", "Bradesco 1070"),
    SeedPayment("Empréstimos", "Nubank 400"),
    SeedPayment("Empréstimos", "Nubank 990"),
    SeedPayment("Empréstimos", "CMIR 1.2K 08"),
    SeedPayment("Empréstimos", "CMIR 2.4K 17"),
    SeedPayment("Empréstimos", "CMIR 1.2K 22"),
    SeedPayment("Empréstimos", "CMIR 6K 29"),
    SeedPayment("Empréstimos", "CMIR 6K 30")
)
