package br.com.controlepagamentos

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val bg = Color(0xFF0D111B)
private val panel = Color(0xFF171F2D)
private val accent = Color(0xFF79A9FF)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        val dao = PaymentDatabase.get(this).paymentDao()
        lifecycleScope.launch {
            if (dao.count() == 0) dao.insertAll(initialPayments.map {
                Payment(category = it.category, description = it.description)
            })
        }
        setContent {
            val payments by dao.observeAll().collectAsState(initial = emptyList())
            var selected by remember { mutableStateOf<Payment?>(null) }
            var creating by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = darkColorScheme(
                background = bg, surface = panel, primary = accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Surface(Modifier.fillMaxSize(), color = bg) {
                    Column(Modifier.fillMaxSize().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("CONTROLE DE PAGAMENTOS", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold)
                                Text("Organização mensal das contas", color = Color.LightGray)
                            }
                            IconButton(onClick = { creating = true }) {
                                Icon(Icons.Default.Add, contentDescription = "Adicionar")
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        val total = payments.sumOf { it.amountCents }
                        val paid = payments.filter { it.isPaid }.sumOf { it.amountCents }
                        Card(colors = CardDefaults.cardColors(containerColor = panel),
                            shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Summary("TOTAL CADASTRADO", money(total))
                                Summary("PAGO", money(paid))
                                Summary("PENDENTE", money(total - paid))
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            val groups = payments.groupBy { it.category }
                            groups.forEach { (category, list) ->
                                item {
                                    Text(category.uppercase(), color = accent,
                                        style = MaterialTheme.typography.labelLarge,
                                        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
                                }
                                items(list, key = { it.id }) { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth().clickable { selected = item },
                                        colors = CardDefaults.cardColors(containerColor = panel),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Row(Modifier.fillMaxWidth().padding(13.dp),
                                            verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(item.description, fontWeight = FontWeight.SemiBold)
                                                Text("Vencimento: dia ${item.dueDay}  •  ${money(item.amountCents)}",
                                                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                            }
                                            IconButton(onClick = {
                                                lifecycleScope.launch { dao.update(item.copy(isPaid = !item.isPaid)) }
                                            }) {
                                                Icon(Icons.Default.CheckCircle,
                                                    contentDescription = "Alternar pagamento",
                                                    tint = if (item.isPaid) Color(0xFF55D69E) else Color.Gray)
                                            }
                                            IconButton(onClick = { selected = item }) {
                                                Icon(Icons.Default.Edit, contentDescription = "Editar", tint = accent)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (selected != null) PaymentDialog(selected!!, onDismiss = { selected = null }) {
                    lifecycleScope.launch { dao.update(it); selected = null }
                }
                if (creating) PaymentDialog(null, onDismiss = { creating = false }) {
                    lifecycleScope.launch { dao.insert(it); creating = false }
                }
            }
        }
    }
}

@Composable private fun Summary(label: String, value: String) {
    Column {
        Text(label, color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
    }
}
private fun money(cents: Long): String =
    NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(cents / 100.0)

@Composable private fun PaymentDialog(
    payment: Payment?,
    onDismiss: () -> Unit,
    onSave: (Payment) -> Unit
) {
    var description by remember(payment?.id) { mutableStateOf(payment?.description ?: "") }
    var category by remember(payment?.id) { mutableStateOf(payment?.category ?: "Moradia") }
    var amount by remember(payment?.id) { mutableStateOf(
        payment?.amountCents?.let { "%.2f".format(Locale.US, it / 100.0) } ?: "0,00"
    ) }
    var dueDay by remember(payment?.id) { mutableStateOf((payment?.dueDay ?: 10).toString()) }
    var notes by remember(payment?.id) { mutableStateOf(payment?.notes ?: "") }
    var paid by remember(payment?.id) { mutableStateOf(payment?.isPaid ?: false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (payment == null) "Novo pagamento" else "Editar pagamento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(description, { description = it }, label = { Text("Descrição") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Categoria") }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text("Valor (R$)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(dueDay, { dueDay = it.filter(Char::isDigit).take(2) },
                    label = { Text("Dia do vencimento (1 a 31)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(notes, { notes = it }, label = { Text("Observações") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = paid, onCheckedChange = { paid = it })
                    Text("Pagamento realizado")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val normalized = amount.trim().replace(".", "").replace(",", ".")
                val cents = ((normalized.toDoubleOrNull() ?: 0.0) * 100).toLong()
                val day = (dueDay.toIntOrNull() ?: 10).coerceIn(1, 31)
                onSave(Payment(payment?.id ?: 0, category.ifBlank { "Outros" },
                    description.ifBlank { "Novo pagamento" }, cents, day, paid, notes))
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
