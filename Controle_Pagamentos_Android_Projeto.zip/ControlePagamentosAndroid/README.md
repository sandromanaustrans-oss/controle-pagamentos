# Controle de Pagamentos (Android)

Projeto inicial Android nativo em Kotlin + Jetpack Compose, com banco local Room e interface em modo escuro.

## Recursos incluídos
- 30 lançamentos iniciais nas categorias Seguros, Cartões, Moradia, Transporte e Empréstimos.
- Edição individual de descrição, categoria, valor, dia de vencimento e observações.
- Marcação individual de pagamento realizado.
- Resumo dos valores cadastrados, pagos e pendentes.
- Dados armazenados localmente no aparelho.

## Gerar o APK pelo GitHub
1. Envie todos os arquivos deste projeto para a raiz do repositório `controle-pagamentos`.
2. Faça o commit na branch `main`.
3. Abra a aba **Ações** (Actions) do GitHub.
4. Entre em **Gerar APK Android** e aguarde a execução terminar.
5. Abra a execução concluída e baixe o artefato `controle-pagamentos-apk`.

## Observações da versão inicial
- O projeto gera um APK de depuração (debug), adequado para instalação e testes.
- O alerta no dia do vencimento ainda precisa ser conectado ao agendador de notificações; a permissão de notificações já está declarada.
- A proteção por PIN/biometria e a rotina de recorrência mensal automática precisam ser implementadas antes de considerar a versão pronta para uso diário.
